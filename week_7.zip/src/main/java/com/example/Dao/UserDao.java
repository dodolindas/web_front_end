package com.example.Dao;

import com.example.pojo.User;
import com.example.util.DBConnect;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDao {
    private Connection connection;

    public UserDao() throws Exception {
        connection = DBConnect.getConnection();
    }

    // 获取全部用户信息
    public List<User> selectUsers() throws Exception {

        List<User> users = new ArrayList<User>();
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("select * from tb_user");
            while (resultSet.next()) {
                User user = new User();
                user.setId(resultSet.getInt("id"));
                user.setUsername(resultSet.getString("username"));
                user.setPassword(resultSet.getString("password"));
                users.add(user);
            }
            connection.close();
            statement.close();
            resultSet.close();
        } catch (Exception e) {
            e.getMessage();
        }
        return users;
    }

    public Integer loginUser(String username, String password) throws SQLException {
        int flag=0;

        String query = "SELECT * FROM tb_user WHERE username = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                String storedPassword = resultSet.getString("password");
                if (storedPassword.equals(password)) {
                    flag=1;
                }else{
                    flag=0;
                }
            }else{
                flag=-1;
            }

            resultSet.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return flag;
    }
}
