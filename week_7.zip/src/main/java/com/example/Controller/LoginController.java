package com.example.Controller;

import com.alibaba.fastjson.JSON;
import com.example.Service.RedisLogic;
import com.example.Service.UserService;
import com.example.pojo.User;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

@WebServlet("/login")
public class LoginController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) {
        response.setContentType("application/json;charset=utf-8");
        try {
            UserService userService = new UserService();

            // 读取请求的内容
            BufferedReader reader = request.getReader();
            StringBuilder requestBody = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                requestBody.append(line);
            }

            // 解析 JSON 数据
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode rootNode = objectMapper.readTree(requestBody.toString());

            // 获取用户名和密码
            String username = rootNode.get("username").asText();
            String password = rootNode.get("password").asText();

            // 获取验证码
            String imageCode = rootNode.get("imagecode").asText();

            String uuid = rootNode.get("uuid").asText();

            //验证验证码
            RedisLogic redisLogic = new RedisLogic();
            if(!imageCode.equals(redisLogic.getRedis(uuid))){
                response.getWriter().write("imageCode error");
                return;
            }

            Integer login = userService.login(username, password);
            if(login==1){
                response.getWriter().write("success");
            } else if (login==0) {
                response.getWriter().write("password error");
            }else{
                response.getWriter().write("username error");
            }


//            if (flag){
//                response.setContentType("application/json");
//                response.setCharacterEncoding("UTF-8");
//                response.getWriter().write("success");
//            }else {
//                response.getWriter().write("error");
//            }



        }catch (Exception e){
            e.getMessage();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) {
        this.doGet(request, response);
    }
}
