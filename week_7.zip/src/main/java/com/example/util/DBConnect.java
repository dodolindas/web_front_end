package com.example.util;

import java.sql.*;

public class DBConnect {
    public static Connection getConnection() {
        String url = "jdbc:mysql://127.0.0.1:3306/db1?useSSL=false";
        String user = "root";
        String pwd = "252525";
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            conn = DriverManager.getConnection(url, user, pwd);
        } catch (Exception e) {
            e.getMessage();
        }
        return conn;
    }
}
