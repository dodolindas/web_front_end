package com.example.Service;

import com.example.Dao.UserDao;
import com.example.pojo.User;

import java.util.List;
public class UserService {
    private UserDao userDao;

    public UserService() throws Exception {
        userDao = new UserDao();
    }

    public List<User> selectUsers() {
        List<User> users;
        try {
            UserDao userDao = new UserDao();
            users = userDao.selectUsers();
        } catch (Exception e) {
            e.getMessage();
            return null;
        }
        return users;
    }

    public Integer login(String username, String password) throws Exception {

        UserDao userDao = new UserDao();
        Integer integer = userDao.loginUser(username, password);
        if(integer==0){
            return 0;
        }else if(integer==1){
            return 1;
        }else{
            return -1;
        }
    }
}