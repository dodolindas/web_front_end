package com.example.Service;

import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

public class RedisLogic {

    // 设置键值对
    public void setRedis(String key, String value) {
        //创建一个配置对象
        JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
        //设置参数
        //最大空闲数
        jedisPoolConfig.setMaxIdle(50);
        //最大连接数
        jedisPoolConfig.setMaxTotal(50);
        //创建数据库连接池对象
        JedisPool pool = new JedisPool("127.0.0.1", 6379);
        //获取连接
        redis.clients.jedis.Jedis resource = pool.getResource();
        //使用
        resource.set(key, value);
        //归还连接到数据库连接池
        resource.close();
    }

    // 根据键取值
    public String getRedis(String key) {
        String result = "";
        //创建一个配置对象
        JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
        //设置参数
        //最大空闲数
        jedisPoolConfig.setMaxIdle(50);
        //最大连接数
        jedisPoolConfig.setMaxTotal(50);
        //创建数据库连接池对象
        JedisPool pool = new JedisPool("127.0.0.1", 6379);
        //获取连接
        redis.clients.jedis.Jedis resource = pool.getResource();
        //使用
        result = resource.get(key);
        //归还连接到数据库连接池
        resource.close();
        return result;
    }

    public static void main(String[] args) {

        RedisLogic redisLogic = new RedisLogic();
        redisLogic.setRedis("a", "1");
        System.out.println(redisLogic.getRedis("a"));
    }
}