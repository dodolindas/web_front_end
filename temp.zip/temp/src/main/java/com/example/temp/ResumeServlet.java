package com.example.temp;

import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet(name = "resumeServlet", value = "/resume-servlet")
public class ResumeServlet extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        response.setCharacterEncoding("utf-8");
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head><title>个人简历</title></head>");
        out.println("<body>");
        out.println("<div align='center'>");
        out.println("<h1>个人简历</h1><br/>");
        out.println("<table border='1px' width='800px' style='font-size:24px'>");
        out.println("<tr><td width='25%' align='center'>姓名：</td><td width='25%' align='center'>彭靖强</td><td width='25%' align='center'>政治面貌：</td><td width='25%' align='center'>团员</td></tr>");
        out.println("<tr><td width='25%' align='center'>手机号码：</td><td width='25%' align='center'>18000000000</td><td width='25%' align='center'>电子邮箱：</td><td width='25%' align='center'>123456@qq.com</td></tr>");
        out.println("<tr><td width='25%' align='center'>年龄：</td><td width='25%' align='center'>23</td><td width='25%' align='center'>学历：</td><td width='25%' align='center'>本科</td></tr>");
        out.println("<tr><td width='100%' align='left' colspan='4'>教育经历：<br/>1.宁波市鄞州区堇山小学 2008年9月-2014年9月<br/>2.宁波市兴宁中学 2014年9月-2017年9月<br/>3.宁波市鄞州中学 2017年9月-2020年9月<br/></td></tr>");
        out.println("<tr><td width='100%' align='left' colspan='4'>实习经历：<br/>1.拼夕夕(上海)网络科技有限公司 2013年10月-2013年12月 前端开发<br/>2.北京京西世纪贸易有限公司 2014年03月-2014年05月 Java后端开发<br/></td></tr>");
        out.println("<img src='cv-photo.jpg'/>");
        out.println("</table>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }
}
